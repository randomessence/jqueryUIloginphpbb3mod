# FAQ

## What do donations go towards?
Donations are used to keep the hosting company happy with regular payments and help to keep me on my feet while I develop
this much loved library [citation needed]! So donations are always welcome and if you really enjoy using qTip2, please consider
donating. You know you want to deep down! For more information on donations checkout the [donations page][donate].

## Are you SURE it's free?
Absolutely! qTip2 is free and will always be free, unless of course I become homeless and have to live out of a box... then we'll see. But until then, don't worry your pretty little head.
qTip<sup>2</sup> is dual licensed under the MIT and GPLv2 licenses, so you can do whatever you want with it... as long as you include
a copy of the license! Check out the [jQuery licensing page][license] for more details.

## Who else works on qTip2?
I'm currently the only developer working on qTip2. If your interested in helping out, fork this repo or contact me and we can talk
about how you can get involved.

[donate]: http://craigsworks.com/projects/qtip2/donate/
[license]: http://jquery.org/license/